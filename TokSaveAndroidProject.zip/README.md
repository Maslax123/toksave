# TokSave PRO Android APK

This project wraps the supplied `index.html` + `manifest.json` in a native Android WebView.

## Build debug APK

1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Choose **Build > Build APK(s)**.
4. The APK will be under `app/build/outputs/apk/debug/`.

The app needs internet access because the supplied website calls external services such as the TikWM API and external web assets.

## GitHub Actions

Push this project to GitHub. The included workflow builds a debug APK automatically. Download it from the workflow run's **Artifacts** section.

## Important

The supplied manifest is a web/PWA manifest. Android APK metadata comes from `AndroidManifest.xml`; both are kept because the website also uses the web manifest.
