plugins {
    id("com.android.application")
}

android {
    namespace = "com.toksave.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.toksave.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            minifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.12.1")
}
